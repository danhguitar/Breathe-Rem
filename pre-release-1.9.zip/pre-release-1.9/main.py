import pygame
from engine import *
from time import sleep

pygame.init()

while True:
  if gamestate == gamestates[0]:
    current_resolution = read_res()
    STARTSCREEN = pygame.display.set_mode(current_resolution)
    CLOCK = pygame.time.Clock()
    RES_PICK_LBL = FONT.render("pick a resolution:", True, "white")
    while gamestate == "startup":
      for ev in pygame.event.get():
        if ev.type == pygame.QUIT:
          exit(0)
        if ev.type == pygame.MOUSEBUTTONDOWN:
          MOUSE = pygame.mouse.get_pos()
          #print(MOUSE)

          if MOUSE[0] > 35 and MOUSE[0] < 85 and MOUSE[1] > 50 and MOUSE[1] < 100:
            current_resolution = update_resolution("450p")

          if MOUSE[0] > 95 and MOUSE[0] < 145 and MOUSE[1] > 50 and MOUSE[1] < 100:
            current_resolution = update_resolution("720p")

          if MOUSE[0] > 155 and MOUSE[0] < 205 and MOUSE[1] > 50 and MOUSE[1] < 100:
            current_resolution = update_resolution("768p")

          if MOUSE[0] > 215 and MOUSE[0] < 265 and MOUSE[1] > 50 and MOUSE[1] < 100:
            current_resolution = update_resolution("900p")

          if MOUSE[0] > 275 and MOUSE[0] < 325 and MOUSE[1] > 50 and MOUSE[1] < 100:
            current_resolution = update_resolution("1080p")

          if MOUSE[0] > 335 and MOUSE[0] < 385 and MOUSE[1] > 50 and MOUSE[1] < 100:
            current_resolution = update_resolution("1440p")

          if MOUSE[0] > ((current_resolution[0] / 2) - 50) and MOUSE[0] < ((current_resolution[0] / 2) + 50) and MOUSE[1] > ((current_resolution[1] / 2)) - 25 and MOUSE[1] < ((current_resolution[1] / 2) + 25):
            gamestate = "titlescreen"

      START_BG = pygame.transform.scale(START_BG, (current_resolution))
      STARTSCREEN.blit(START_BG, (0, 0))

      for BTTN in RES_BTTN_LIST:
        STARTSCREEN.blit(BTTN, RES_BTTN_COORDS.get(BTTN))

      STARTSCREEN.blit(RES_PICK_LBL, (125, 10))

      STARTSCREEN.blit(BTTN_START, ((current_resolution[0] / 2) - 50, (current_resolution[1] / 2) - 25))

      pygame.display.flip()
      CLOCK.tick(60)





  if gamestate == gamestates[1]:
    current_resolution = read_res()

    TITLE_TEXT = TITLE_FONT.render("Breathe Remastered", True, "white")

    WIN = pygame.display.set_mode(current_resolution)
    pygame.display.set_caption("breathe remastered (prerelease 1.9)")

    TITLE_BG = pygame.transform.scale(WIN_BG_BLACK, (current_resolution))

    while gamestate == gamestates[1]:
      for ev in pygame.event.get():
        if ev.type == pygame.QUIT:
          exit(0)
        if ev.type == pygame.MOUSEBUTTONDOWN:
          MOUSE = pygame.mouse.get_pos()
          #print(MOUSE)
          if MOUSE[0] > ((current_resolution[0] / 2) - 50) and MOUSE[0] < ((current_resolution[0] / 2) + 50) and MOUSE[1] > ((current_resolution[1] / 2) - 25) and MOUSE[1] < ((current_resolution[1] / 2) + 25):
            gamestate = gamestates[2]
          #if MOUSE[0] > ((current_resolution[0] / 2) - 50) and MOUSE[0] < ((current_resolution[0] / 2) + 50) and MOUSE[1] > ((current_resolution[1] / 2) + 50) and MOUSE[1] < ((current_resolution[1] / 2) + 100):
            #player = load(player)
          if MOUSE[0] > 20 and MOUSE[0] < 95 and MOUSE[1] > (current_resolution[1] - 75) and MOUSE[1] < (current_resolution[1] - 25):
            gamestate = gamestates[0]
          # (current_resolution[0] - 215, current_resolution[1] - 195)
          if MOUSE[0] > (current_resolution[0] - 215) and MOUSE[0] < (current_resolution[0] - 15) and MOUSE[1] > (current_resolution[1] - 195) and MOUSE[1] < (current_resolution[1] - 15):
            clear_save()

      WIN.blit(TITLE_BG, (0, 0))
      WIN.blit(TITLE_TEXT, (((current_resolution[0] / 2) - (TITLE_TEXT.get_width() / 2)), ((current_resolution[1] / 2) - 200)))
      WIN.blit(RESOLUTION_SCREEN_BTTN, (20, (current_resolution[1]) - 75))
      WIN.blit(BTTN_START, (((current_resolution[0] / 2) - 50), ((current_resolution[1] / 2) - 25)))
      #WIN.blit(BTTN_LOAD, (((current_resolution[0] / 2) - 50),  ((current_resolution[1] / 2) + 50)))
      WIN.blit(CLEAR_SAVE_BTTN, (current_resolution[0] - 215, current_resolution[1] - 195))

      pygame.display.flip()
      CLOCK.tick(60)




  if gamestate == gamestates[2]:
    FRAMERATE = 60
    # player setup
    player = Player(1, 1, 0, True)
    player = load(player)

    """
    SCREEN SETUP
    SCREEN SETUP
    SCREEN SETUP
    """

    # button coords
    BTTN_LVL_UP_COORDS_X = ((current_resolution[0] / 2) - WIN_BTTN_LVL_UP_WHT.get_width()) - BTTN_SIZE_WID
    BTTN_LVL_UP_COORDS_Y = ((current_resolution[1] / 2) - WIN_BTTN_LVL_UP_WHT.get_height())
    BTTN_MULTIPLIER_UP_COORDS_X = (current_resolution[0] / 2) + BTTN_SIZE_WID
    BTTN_MULTIPLIER_UP_COORDS_Y = ((current_resolution[1] / 2)-WIN_BTTN_LVL_UP_WHT.get_height())

    # background system
    active_bg = WIN_BG_BLACK

    """
    GAME SETUP
    GAME SETUP
    GAME SETUP
    """

    player_speed_buffer = 0

    SPACE_TO_BREATHE_DISP = FONT.render("press SPACE to breathe", True, "white")

    # prompt to start gam player.score == 0 = False

    # Taunt Displays
    GRASS_TAUNT = FONT.render("go touch some grass", True, "black")
    AIR_TAUNT = FONT.render("BREATHE SOME REAL AIR", True, "black")
    WHY_HERE_TAUNT = FONT.render("WHY ARE YOU HERE", True, "black")

    time_list_smh = load_time()
    
    """
    GAME
    GAME
    GAME
    """
    while gamestate == gamestates[2]:

      # auto breathe system
      player.AutoLung()


      # evem detection
      for ev in pygame.event.get():

        # quitting app via X button
        if ev.type == pygame.QUIT:
          save(player.score, player.multiplier, player.level, player.lvl_multi, player.lung_level)
          save_time(time_list_smh[0], time_list_smh[1], time_list_smh[2], time_list_smh[3])
          exit(0)

        if ev.type == pygame.MOUSEBUTTONDOWN:
          # mouse
          MOUSE = pygame.mouse.get_pos()
          if MOUSE[0] > BTTN_LVL_UP_COORDS_X and MOUSE[0] < BTTN_LVL_UP_COORDS_X + WIN_BTTN_LVL_UP_WHT.get_width() and MOUSE[1] > BTTN_LVL_UP_COORDS_Y and MOUSE[1] < BTTN_LVL_UP_COORDS_Y + WIN_BTTN_LVL_UP_WHT.get_height():
            if (player.score) >= ((player.level) * 1000):
              (player.score) -= ((player.level) * 1000)
              player.level_increase("player")
          if MOUSE[0] > BTTN_MULTIPLIER_UP_COORDS_X and MOUSE[0] < (BTTN_MULTIPLIER_UP_COORDS_X + (WIN_BTTN_LVL_UP_WHT.get_width())) and MOUSE[1] > BTTN_MULTIPLIER_UP_COORDS_Y and MOUSE[1] < (BTTN_MULTIPLIER_UP_COORDS_Y + (WIN_BTTN_LVL_UP_WHT.get_height())):
            if (player.score) >= (player.lvl_multi) * 1250:
              (player.score) -= (player.lvl_multi * 1250)
              player.level_increase("multiplier")
          # (((current_resolution[0] / 2) - 50), ((current_resolution[1] / 2) - 200)))
          if MOUSE[0] > ((current_resolution[0] / 2) - 50) and MOUSE[0] < ((current_resolution[0] / 2) + 50) and MOUSE[1] > ((current_resolution[1] / 2) - 200) and MOUSE[1] < ((current_resolution[1] / 2) - 120):
            if (player.score) >= ((player.lung_level) * 1500):
              if (player.lung_level == 0):
                if player.score >= 1500:
                  player.lung_level += 1
                  (player.score) -= ((player.lung_level) * 1500)
              else:
                player.lung_level += 1
                (player.score) -= ((player.lung_level) * 1500)

          #if MOUSE[0] > 10 and MOUSE[0] < 110 and MOUSE[1] > 10 and MOUSE[1] < 60:
            #save(player.score, player.multiplier, player.level, player.lvl_multi, player.lung_level)


      # key detection
      keys = pygame.key.get_pressed()

      # space to breathe 
      if keys[pygame.K_SPACE]:

        # speed buffer reset
        if player_speed_buffer > 100:
          player_speed_buffer = 0

        # increases buffer
        player_speed_buffer += 1

        # implements buffer
        if player_speed_buffer % 2 == 0:
          player.score_increase(1)


      """
      TIME SYSTEM
      TIME SYSTEM
      TIME SYSTEM
      """
      time_list_smh[0] += 1
      if time_list_smh[0] == FRAMERATE:
        time_list_smh[1] += 1
        time_list_smh[0] = 0
      #if time_list_smh[0] <= 0:
        #sleep(5)
      if time_list_smh[1] >= FRAMERATE:
        time_list_smh[2] += 1 
        time_list_smh[1] = 0


      """
      SCREEN DRAW SYSTEM
      SCREEN DRAW SYSTEM
      SCREEN DRAW SYSTEM
      """


      # background system; establishes button color as well
      # grass bg
      if player.score >= 5000 and player.score < 20000:
        active_bg = BG_LIST[1]
        button_txt_col = "black"

      # field bg
      elif player.score >= 20000:
        active_bg = BG_LIST[2]
        button_txt_col = "black"

      # black bg
      else:
        active_bg = BG_LIST[0]
        button_txt_col = "white"

      # draws background to screen 
      active_bg = pygame.transform.scale(active_bg, current_resolution)
      WIN.blit(active_bg, (0, 0))

      TIME_DISP = FONT.render(f"time elapsed: {time_list_smh[3]-1}:{time_list_smh[2]-1}:{time_list_smh[1]-1}", True, button_txt_col)
      WIN.blit(TIME_DISP, ((current_resolution[0] - (TIME_DISP.get_width() + 25)), 25))

      if active_bg == BG_LIST[1]:
        WIN.blit(GRASS_TAUNT, (((current_resolution[0] / 2) - GRASS_TAUNT.get_width() / 2 ), 100))
      if active_bg == BG_LIST[2]:
        WIN.blit(GRASS_TAUNT, (((current_resolution[0] / 2) - GRASS_TAUNT.get_width() / 2 ), 100))
        WIN.blit(AIR_TAUNT, (((current_resolution[0] / 2) - AIR_TAUNT.get_width() / 2 ), 150))
      if player.score >= 1000000000000:
        WIN.blit(GRASS_TAUNT, (((current_resolution[0] / 2) - GRASS_TAUNT.get_width() / 2 ), 100))
        WIN.blit(AIR_TAUNT, (((current_resolution[0] / 2) - AIR_TAUNT.get_width() / 2 ), 150))
        WIN.blit(WHY_HERE_TAUNT, (((current_resolution[0] / 2) - WHY_HERE_TAUNT.get_width() / 2), 175))
      if player.score == 0:
        WIN.blit(SPACE_TO_BREATHE_DISP, (((current_resolution[0] / 2) - (SPACE_TO_BREATHE_DISP.get_width() / 2)), ((current_resolution[1] / 4))))


      # labels for upgrades
      SHOP_LABEL = FONT.render("upgrade shop", True, button_txt_col)
      WIN.blit(SHOP_LABEL, (((current_resolution[0] / 2) - (SHOP_LABEL.get_width() / 2)), (current_resolution[1] / 2)))
      SHOP_PLAYER_LABEL = FONT.render("player:", True, button_txt_col)
      WIN.blit(SHOP_PLAYER_LABEL, ((BTTN_LVL_UP_COORDS_X - 2), (BTTN_LVL_UP_COORDS_Y - BTTN_SIZE_HEIGHT / 2)))
      SHOP_MULTIPLIER_LABEL = FONT.render("multiplier:", True, button_txt_col)
      WIN.blit(SHOP_MULTIPLIER_LABEL, (((BTTN_MULTIPLIER_UP_COORDS_X - (BTTN_SIZE_WID / 4)), (BTTN_MULTIPLIER_UP_COORDS_Y - BTTN_SIZE_HEIGHT / 2))))


      # score and multiplier up buttons
      # establishing whether or not to use button
      if player.score >= ((player.level) * 1000):
        display_button_level_up = 1
      else:
        display_button_level_up = 0

      if player.score >= ((player.lvl_multi) * 1250):
        display_button_multiplier_up = 1
      else:
        display_button_multiplier_up = 0


      # displaying the buttons
      # save button
      #WIN.blit(BTTN_SAVE, (10, 10))

      # auto lung button
      WIN.blit(GHOST_LUNG_BTTN, (((current_resolution[0] / 2) - 50), ((current_resolution[1] / 2) - 200)))
      if (player.score) >= ((player.lung_level) * 1500):
        if (player.lung_level == 0):
          if (player.score >= 1500):
            if button_txt_col == "white":
              WIN.blit(AUTO_LUNG_BTTN, (((current_resolution[0] / 2) - 50), ((current_resolution[1] / 2) - 200)))
            if button_txt_col == "black":
              WIN.blit(AUTO_LUNG_BLK_BTTN, (((current_resolution[0] / 2) - 50), ((current_resolution[1] / 2) - 200)))
        else:
          if button_txt_col == "white":
            WIN.blit(AUTO_LUNG_BTTN, (((current_resolution[0] / 2) - 50), ((current_resolution[1] / 2) - 200)))
          if button_txt_col == "black":
            WIN.blit(AUTO_LUNG_BLK_BTTN, (((current_resolution[0] / 2) - 50), ((current_resolution[1] / 2) - 200)))

      # ghost buttons
      WIN.blit(WIN_BTTN_LVL_UP_GRY, (BTTN_LVL_UP_COORDS_X, BTTN_LVL_UP_COORDS_Y))
      WIN.blit(WIN_BTTN_LVL_UP_GRY, (BTTN_MULTIPLIER_UP_COORDS_X, BTTN_LVL_UP_COORDS_Y))

      if display_button_level_up and button_txt_col == "white":
        WIN.blit(WIN_BTTN_LVL_UP_WHT, (BTTN_LVL_UP_COORDS_X, BTTN_LVL_UP_COORDS_Y))
      if display_button_level_up and button_txt_col == "black":
        WIN.blit(WIN_BTTN_LVL_UP_BLK, (BTTN_LVL_UP_COORDS_X, BTTN_LVL_UP_COORDS_Y))

      if display_button_multiplier_up and button_txt_col == "white":
        WIN.blit(WIN_BTTN_LVL_UP_WHT, (BTTN_MULTIPLIER_UP_COORDS_X, BTTN_MULTIPLIER_UP_COORDS_Y))
      if display_button_multiplier_up and button_txt_col == "black":
        WIN.blit(WIN_BTTN_LVL_UP_BLK, (BTTN_MULTIPLIER_UP_COORDS_X, BTTN_MULTIPLIER_UP_COORDS_Y))

      # player score
      PLAYER_SCORE_LABEL = FONT.render(f"score: {player.score}", True, button_txt_col)  
      WIN.blit(PLAYER_SCORE_LABEL, (10, 25))

      # level display
      if player.lung_level > 0:
        PLAYER_LUNG_LVL_DISP = FONT.render(f"lung level: {player.lung_level}", True, button_txt_col)
      else:
        PLAYER_LUNG_LVL_DISP = FONT.render(f"lung level: {player.lung_level}", True, button_txt_col)
      PLAYER_LEVEL_DISP = FONT.render(f"level: {player.level}", True, button_txt_col)
      MULTIPLIER_LEVEL_DISP = FONT.render(f"multiplier level: {player.lvl_multi}", True, button_txt_col)
      
      WIN.blit(PLAYER_LEVEL_DISP, (10, (current_resolution[1] - 50)))
      WIN.blit(MULTIPLIER_LEVEL_DISP, (10, (current_resolution[1] - 30)))
      WIN.blit(PLAYER_LUNG_LVL_DISP, (10, 75))


      # mutiplier display
      MULTIPLIER_DISPLAY = FONT.render(f"multiplier: {player.multiplier}", True, button_txt_col)
      WIN.blit(MULTIPLIER_DISPLAY, (10, 50))



      # draws the screen
      pygame.display.flip()
      CLOCK.tick(FRAMERATE)
