import pygame
from image_load import *
from save import *
from math import fmod
from sys import exit
from time import perf_counter

pygame.init()

"""
engine for breathe-rem
not liscenced
made by an idiot
"""

# all possible resolutions
RESOLUTIONS = {
  "450p" : (800, 450),
  "720p" : (1280, 720),
  "768p" : (1366, 768),
  "900p" : (1600, 900),
  "1080p" : (1920, 1080),
  "1440p" : (2560, 1440)
}

# sets default resolution
current_resolution = RESOLUTIONS.get("450p")


# button list for resolution buttons
RES_BTTN_LIST = [
  BTTN_RES_450,
  BTTN_RES_720,
  BTTN_RES_768,
  BTTN_RES_900,
  BTTN_RES_1080,
  BTTN_RES_1440
]


# coordinates for resolution buttons on the start screen
RES_BTTN_COORDS = {
  BTTN_RES_450 : (35, 50),
  BTTN_RES_720 : (95, 50),
  BTTN_RES_768 : (155, 50),
  BTTN_RES_900 : (215, 50),
  BTTN_RES_1080 : (275, 50),
  BTTN_RES_1440 : (335, 50)
}


# gamestates to tell whether to be on the titlescreen, startscreen, or game
gamestates = {
  0 : "startup",
  1 : "titlescreen",
  2 : "game"
}
# default resolution
gamestate = gamestates[1]


# window setup
SCREEN_SIZE = current_resolution
WIN_WID = current_resolution[0]
WIN_HIGH = current_resolution[1]

# button sizes
BTTN_SIZE_WID = WIN_BTTN_LVL_UP_WHT.get_width()
BTTN_SIZE_HEIGHT = WIN_BTTN_LVL_UP_WHT.get_height()

# backgrounds
BG_LIST = [WIN_BG_BLACK, WIN_BG_GRASS, WIN_BG_BLISS]

# frame timing system
CLOCK = pygame.time.Clock()

# font
FONT = pygame.font.Font("assets/fonts/impact.ttf", 20)
TITLE_FONT = pygame.font.Font("assets/fonts/impact.ttf", 50)




def update_resolution(res_key=str):
  global STARTSCREEN, current_resolution, START_BG, WIN_WID, WIN_HIGH

  old_res = RESOLUTIONS.get("450p")

  res = RESOLUTIONS.get(res_key)

  STARTSCREEN = pygame.display.set_mode(res)
  current_resolution = res

  START_BG = pygame.transform.scale(START_BG, (current_resolution))
  STARTSCREEN.blit(START_BG, (0, 0))

  OK_LABEL = FONT.render("resolution ok?", True, "white")
  STARTSCREEN.blit(OK_LABEL, ((res[0] / 2), (res[1] / 2) - 30))

  STARTSCREEN.blit(BTTN_CHECK, ((res[0] / 2), (res[1] / 2)))

  pygame.display.flip()

  timer_start = perf_counter()

  update_res_del = 1

  while update_res_del:
    time_elapsed = perf_counter()
    if time_elapsed - timer_start >= 10:
      STARTSCREEN = pygame.display.set_mode(old_res)
      START_BG = pygame.transform.scale(START_BG, (old_res))
      pygame.display.flip()
      break
    for ev in pygame.event.get():
      if ev.type == pygame.MOUSEBUTTONDOWN:
        MOUSE = pygame.mouse.get_pos()
        if MOUSE[0] > (res[0] / 2) and MOUSE[0] < ((res[0] / 2) + 50) and MOUSE[1] > (res[1] / 2) and MOUSE[1] < ((res[1] / 2) + 50):
          WIN_WID = current_resolution[0]
          WIN_HIGH = current_resolution[1]
          save_res(current_resolution)
          return res





def ERROR(code=int, line=int):
  if code == 0:
    print(f'Error undetermined')
  elif code == 1:
    print(f"character or multiplier level not int")
  else:
    print("invalid error code")
  exit(0)

def int_checker(item, error):
  if not isinstance(item, int):
    ERROR(error)
  else:
    return item





"""
PLAYER SYSTEM
PLAYER SYSTEM
PLAYER SYSTEM
"""
class Player():

  # creates multiplier
  def create_multiplier(self): 
    if (self.level) == 1 and (self.lvl_multi) == 1:
      multi = 1

    else:
      if int(fmod((self.lvl_multi), 2)) == 0:
        multi = (self.level) + ((self.lvl_multi) * 0.5)
      else:
        multi = (self.level) + .5


    if multi < (self.multiplier):
      return (self.multiplier)

    else:
      return multi


  # creates player system
  def __init__(self, lvl_player=int, lvl_multi=int, lvl_autolng=int, awsisgay=bool):
    lvl_player = (int_checker(lvl_player, 1))
    self.lvl_multi = (int_checker(lvl_multi, 1))

    self.level = lvl_player
    self.multiplier = 0
    self.multiplier = (self.create_multiplier())
    self.lung_level = 0

    self.score = 0


  # score increase system; increases score
  def score_increase(self, amount):
    amount = (int_checker(amount, 2))

    self.score = int((self.score) + (amount * (self.multiplier)))


  # level increasing system
  def level_increase(self, type):
    if type == "player":
      self.level += 1
    elif type == "multiplier":
      self.lvl_multi += 1
    elif type == "lung":
      self.lung_level += 1
    else:
      ERROR(0)

    self.multiplier = self.create_multiplier()


  # auto-lung system
  def AutoLung(self):
    if not (self.lung_level <= 0):
      self.score += int(((self.lung_level * 10) * self.multiplier))