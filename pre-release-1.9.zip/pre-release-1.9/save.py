"""
SAVE SYSTEM
SAVE SYSTEM
SAVE SYSTEM
"""

def save_res(current_res):
  file = open("assets/save/resolution.sav", "w")
  file.write(f"{current_res[0]}\n{current_res[1]}\n")
  file.close()


def read_res():
  file = open("assets/save/resolution.sav", "r")
  res = []
  for line in file:
    length = ""
    i = 0
    while line[i] != "\n":
      length += line[i]
      i += 1
    length = int(length)
    res.append(length)
  file.close()
  resolution = (res[0], res[1])
  return resolution


def save_time(tick, sec, min, hour):
  file = open("assets/save/time.sav", "w")
  file.write(f"{tick}\n{sec}\n{min}\n{hour}\n")
  file.close()

def load_time():
  file = open("assets/save/time.sav", "r")
  time_list_smh = []
  for line in file:
    i = 0
    length = ""
    while line[i] != "\n":
        length += line[i]
        i += 1
    time_list_smh.append(int(i))
  file.close()
  return time_list_smh


def read_save():
  file = open("assets/save/save.sav", "r")
  stat_list = []
  for line in file:
      stat = ""
      i = 0
      while line[i] != "\n":
          stat += line[i]
          i += 1
      stat_list.append(stat)
  file.close()
  return stat_list

def save(score=int, multiplier=int, level=int, multi_level=int, lung_level=int):
  file = open("assets/save/save.sav", "w")
  file.write(f"{score}\n{multiplier}\n{level}\n{multi_level}\n{lung_level}\n")
  file.close()
    

def load(player):
  stats = read_save()
  player.score = int(stats[0])
  player.multiplier = float(stats[1])
  player.level = int(stats[2])
  player.lvl_multi = int(stats[3])
  player.lung_level = int(stats[4])
  return player

def clear_save():
  save(0, 1, 1, 1, 0)